CREATE TRIGGER trg_customer_dln_update_timestamp
ON customer_dln
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE customer_dln
    SET updated_at = GETDATE()
	FROM customer_dln m	INNER JOIN inserted i ON m.id = i.id;
END;
go

