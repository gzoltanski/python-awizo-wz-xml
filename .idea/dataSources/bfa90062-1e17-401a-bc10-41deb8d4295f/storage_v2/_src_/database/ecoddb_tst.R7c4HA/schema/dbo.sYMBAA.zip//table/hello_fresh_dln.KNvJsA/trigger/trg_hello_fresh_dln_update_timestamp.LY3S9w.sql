CREATE TRIGGER trg_hello_fresh_dln_update_timestamp
ON hello_fresh_dln
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE hello_fresh_dln
    SET updated_at = GETDATE()
	FROM hello_fresh_dln m	INNER JOIN inserted i ON m.id = i.id;
END;
go

