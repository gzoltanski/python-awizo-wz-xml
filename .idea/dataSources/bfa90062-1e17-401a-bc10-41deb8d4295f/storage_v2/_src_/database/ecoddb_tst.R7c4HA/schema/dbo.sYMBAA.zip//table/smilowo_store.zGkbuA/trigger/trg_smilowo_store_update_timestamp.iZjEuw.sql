CREATE TRIGGER trg_smilowo_store_update_timestamp
ON smilowo_store
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE smilowo_store
    SET updated_at = GETDATE()
	FROM smilowo_store m	INNER JOIN inserted i ON m.store_number = i.store_number;
END;
go

