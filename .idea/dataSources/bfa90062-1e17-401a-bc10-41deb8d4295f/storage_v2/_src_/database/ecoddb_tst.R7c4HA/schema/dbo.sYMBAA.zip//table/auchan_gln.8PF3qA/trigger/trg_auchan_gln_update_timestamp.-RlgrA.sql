CREATE TRIGGER trg_auchan_gln_update_timestamp
ON auchan_gln
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE auchan_gln
    SET updated_at = GETDATE()
	FROM auchan_gln m	INNER JOIN inserted i ON m.gln = i.gln;
END;
go

