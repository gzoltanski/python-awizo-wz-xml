CREATE TRIGGER trg_parent_customer_update_timestamp
ON parent_customer
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE parent_customer
    SET updated_at = GETDATE()
	FROM parent_customer m	INNER JOIN inserted i ON m.id = i.id;
END;
go

